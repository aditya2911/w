const express = require("express");
const app = express();
const port = 3001;
const router = express.Router();
const bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended:true
}))
const moongoose = require("mongoose");
// const ejs  =require('ejs');
app.set('view engine','ejs');
const mongodb = require("mongodb");
// const { default: mongoose } = require("mongoose");
const MongoClient = mongodb.MongoClient;

const uri = "mongodb+srv://Aditya:aditya@cluster0.cjcxybq.mongodb.net/?retryWrites=true&w=majority/test";
const client = new MongoClient(uri,{useNewUrlParser:true,useUnifiedTopology:true});


const studentSchema = {
    _id:Number,
    name:String,
    department:String,
}
const Student = moongoose.model('students',studentSchema);

async function connect(){

        
    
    try{
        await moongoose.connect(uri);
        console.log("Conneceted to mongoDb");
        let temp;
        app.get('/',(req,res)=>{
            Student.find({},function(err,student){
                res.render('index',{
                    studentList:student
                })
            })
            // res.send("data has been fetched");
            

        })

    }
    catch(error){
        console.log(error)
    }



}

connect()

app.get("/:id",(req,res)=>{
    let id = req.params.id;
    Student.findById({_id:id},function(err,student){
        res.send(
            student
        )
    })
})


app.post('/',function(req,res,next){
    const data = new Student({
        // _id:4,
        // name:"Arshita",
        // department:"BSc CS"
        _id:req.body['id'],
        name:req.body["name"],
        department:req.body["department"]
    }

    )

    data.save(function(err,data){
        if(err)return console.error(err);
    })
    res.send("data has been added succesfully");

})


app.delete("/:id",async(req,res)=>{
    const id =req.params.id
    Student.findOneAndRemove({_id:id},function(err){
        if (err) return res.send({ error: err });
        res.send({ message: "Data deleted successfully!" });
    })
    res.send("data has been deleted");
})


app.put("/update/:id",async(req,res)=>{
    const id =req.params.id

    

   let  name=req.body["name"];
   let department=req.body["department"]
    Student.findOneAndUpdate({_id:id},{$set:{name:name,department:department}},{new:false},function(err,data){
        if (err) return res.status(500).send(err);
        if(data == null){
            res.send("nothing found")
        }
        else{
        }
        res.send("data has been updated");

    })
})

app.use("/deleteAll",async(req,res)=>{
    Student.collection.drop((err) => {
        if (err) {
            console.error(err);
        } else {
            console.log('Collection dropped successfully');
        }
    });
    res.send("entire data has been deleted");
})
app.use(express.json());
app.use('/po',router);
app.use(express.static((__dirname)+'/views'))
app.listen(port,()=>{
    console.log(`Student app listening at http://localhost:${port}`);
})